package com.easyfitness.intro;

import android.content.Intent;
import android.os.Bundle;

import com.easyfitness.DAO.DAOProfil;
import com.easyfitness.R;
import com.heinrichreimersoftware.materialintro.app.IntroActivity;
import com.heinrichreimersoftware.materialintro.slide.FragmentSlide;
import com.heinrichreimersoftware.materialintro.slide.SimpleSlide;
import com.heinrichreimersoftware.materialintro.slide.Slide;

public class MainIntroActivity extends IntroActivity {


    public static final String EXTRA_FINISH_ENABLED = "com.heinrichreimersoftware.materialintro.demo.EXTRA_FINISH_ENABLED";
    public static final String EXTRA_GET_STARTED_ENABLED = "com.heinrichreimersoftware.materialintro.demo.EXTRA_GET_STARTED_ENABLED";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();


        boolean getStartedEnabled = intent.getBooleanExtra(EXTRA_GET_STARTED_ENABLED, false);

        setFullscreen(false);

        super.onCreate(savedInstanceState);


        setButtonCtaVisible(getStartedEnabled);
        setButtonCtaTintMode(BUTTON_CTA_TINT_MODE_TEXT);


        addSlide(new SimpleSlide.Builder()
            .title(R.string.titleSlideOpenSource)
            .description(R.string.textSlideOpenSource)
            .image(R.drawable.group_hi_res_512)
            .background(R.color.background_even)
            .backgroundDark(R.color.background_odd)
            .scrollable(true)
            .build());

/*
        final Slide permissionsSlide;
        if (permissions) {
            permissionsSlide = new SimpleSlide.Builder()
                .title(R.string.introSlide3Title)
                .description(R.string.introSlide3Text)
                .image(R.drawable.ic_settings_black_48dp)
                .background(R.color.tableheader_background)
                .backgroundDark(R.color.background_odd)
                .scrollable(true)
                .permissions(new String[]{Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE})
                .build();
            addSlide(permissionsSlide);
        } else {
            permissionsSlide = null;
        }
*/

        // Initialisation des objets DB
        DAOProfil mDbProfils = new DAOProfil(this.getApplicationContext());

        // Pour la base de donnee profil, il faut toujours qu'il y ai au moins un profil
        if (mDbProfils.getCount() == 0) {
            final Slide profileSlide;
            // Ouvre la fenetre de creation de profil
            profileSlide = new FragmentSlide.Builder()
                .background(R.color.background_even)
                .backgroundDark(R.color.launcher_background)
                .fragment(NewProfileFragment.newInstance())
                .build();
            addSlide(profileSlide);
        }
    }
}
